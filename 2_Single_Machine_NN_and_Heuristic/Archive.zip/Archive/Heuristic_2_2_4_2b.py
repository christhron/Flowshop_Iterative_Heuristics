import numpy as np
import itertools

# Function to evaluate the lateness and finish time for a given permutation of tasks
def eval_perm_ct_fn(atmp, xtmp, dtmp, ptmp, qtmp):
    ntmp = len(atmp)
    ytmp = np.zeros(ntmp)  # Initialize the list of finish times
    ytmp[0] = atmp[0] + xtmp[0]  # Finish time for the first task
    late = max(ytmp[0] - dtmp[0], 0)  # Calculate the lateness for the first task
    late = qtmp[0] * late + ptmp[0] * (late > 0)  # Calculate the lateness penalty

    # Calculate finish times and lateness penalties for each task
    for k in range(1, ntmp):
        ytmp[k] = max(ytmp[k - 1], atmp[k]) + xtmp[k]  # Finish time of task k
        late_add = max(0, ytmp[k] - dtmp[k])  # Calculate lateness of task k
        late += qtmp[k] * late_add + ptmp[k] * (late_add > 0)  # Add the lateness penalty

    return late, float(ytmp[-1])

# Function to generate  permutations of jobs

def generate_initial_permutations(partial_list1, J, initial = ()):
    masque = np.isin(partial_list1, list(initial))
    preliminary_order = partial_list1[~masque][:J]
    initial_permutations = []

    for job in preliminary_order:
        remaining_tasks = [task for task in preliminary_order if task != job]
        permutations = itertools.permutations(remaining_tasks, J - 1)

        initial_permutations.extend([initial + (job,) + perm for perm in permutations])

    return initial_permutations
    
#Find lateness and finish times for all jobs
def generate_permutations_in_stages_ct(partial_list, A, X, D, P, Q):
    result = []
    new_lateness = []
    new_finish = []

    for perm in partial_list:
        penalties, finish_time = eval_perm_ct_fn(A[list(perm)], X[list(perm)], D[list(perm)], P[list(perm)], Q[list(perm)])
        result.append(perm)
        new_lateness.append(penalties)
        new_finish.append(finish_time)
        
    
    return np.array(result), np.array(new_lateness), np.array(new_finish)
    
#pareto optimal solutions  
    
def pruneList_fn(tmp_lateness, tmp_finish,tmp_perms):
    late_compare_gt = (tmp_lateness.reshape((1,-1))>tmp_lateness.reshape((-1,1))).astype(int)
    finish_compare_gt = (tmp_finish.reshape((1,-1))>tmp_finish.reshape((-1,1))).astype(int)
    late_compare_ge = (tmp_lateness.reshape((1,-1))>=tmp_lateness.reshape((-1,1))).astype(int)
    finish_compare_ge = (tmp_finish.reshape((1,-1))>=tmp_finish.reshape((-1,1))).astype(int)
    
    index_remove_mx = (late_compare_gt * finish_compare_ge + late_compare_ge * finish_compare_gt) 
    ix = (np.sum(index_remove_mx,axis=0)==0)
    return ix
   
def count_unique_vectors_2d(array):
    # Convertir le tableau 2D en une liste de tuples
    tuples_list = [tuple(row) for row in array]
    
    # Compter les occurrences de chaque tuple
    unique_values, counts = np.unique(tuples_list, return_counts=True, axis=0)
    
    # Créer un dictionnaire avec les vecteurs uniques et leur nombre d'occurrences
    unique_vector_counts = {tuple(val): count for val, count in zip(unique_values, counts)}
    
    # Trier le dictionnaire par valeur (nombre d'occurrences)
    sorted_vector_counts = dict(sorted(unique_vector_counts.items(), key=lambda item: item[1], reverse=True))
    
    return sorted_vector_counts
    
#remove_duplicate
def remove_duplicate(unique_vector_counts):
    # Créer un dictionnaire des paires inversées et des comptes correspondants
    inverse_counts = {tuple(reversed(key)): count for key, count in unique_vector_counts.items()}
    
    # Fusionner les comptes des éléments dupliqués
    unique_vector_counts.update({key: unique_vector_counts.get(key, 0) + count for key, count in inverse_counts.items()})
    
    # Supprimer les paires inversées
    unique_vector_counts = {key: count for key, count in unique_vector_counts.items() if key <= tuple(reversed(key))}
    
    return dict(sorted(unique_vector_counts.items(), key=lambda item: item[1], reverse=True))

# Main function to compute the heuristic
def flow_heurDX_CT2(A, D, X, P, Q):
    A = A.reshape(D.shape)  # Arrival times
    X = X.reshape(D.shape)
    D = D  # Due times
    difference = D
    partial_list1 = np.argsort(difference)
    N = len(difference)  # Number of jobs
    if type(P) != "numpy.ndarray":
        P = P + 0 * A
        Q = Q + 0 * A
    J = 5  # Initial number of tasks to evaluate
    
    # I Initialisation

    #1. Generate all 7 permutations
    
    all_permutations = generate_initial_permutations(partial_list1, 7, initial = ())
    
    #2. Find lateness and finish times for all jobs
  
    result, lateness, finish = generate_permutations_in_stages_ct(all_permutations, A, X, D, P, Q)
    
    # II Identify pareto optimal solutions     
    ix = pruneList_fn(lateness, finish,result)
    pareto_list = result[ix]
    
    #III Iv classification and order the sequences of 3 jobs

    pareto_list_3_jobs = pareto_list[:, 0:3]
    unique_pareto = count_unique_vectors_2d(pareto_list_3_jobs)
    # V Remove duplicate sequences
    pareto_no_dupl = remove_duplicate(unique_pareto) 
    # VI Initial list
    if len(list(pareto_no_dupl.keys())) > 5 : 
        initial_list = list(pareto_no_dupl.keys())[0:5]
    else : 
        initial_list = list(pareto_no_dupl.keys())
    
    #B Iteration
   
   
    initial_jobs = 3
    for it in range(N - 7):
    
         #1. generate 5! schedules with the next 5 jobs in sequence
        partial_list = []
        for initial in initial_list:
            
            partial_list += generate_initial_permutations(partial_list1, J, initial)
            
        
            
        if len(partial_list[0]) < N : 
        
            #2. Find lateness and finish times for all jobs
           
            result, lateness, finish = generate_permutations_in_stages_ct(partial_list, A, X, D, P, Q)
          
            #3 Identify pareto optimal solutions     
            ix = pruneList_fn(lateness, finish,result)
            pareto_list = result[ix]
            
            #4 5 compte and order the sequences of initial jobs +1 

            pareto_list_jobs = pareto_list[:, 0:initial_jobs + 1]
            unique_pareto = count_unique_vectors_2d(pareto_list_jobs)
            
            # 6 Remove duplicate sequences
            pareto_no_dupl = remove_duplicate(unique_pareto) 
            
            # 7 Initial list
            if len(list(pareto_no_dupl.keys())) > 5 : 
                initial_list = list(pareto_no_dupl.keys())[0:5]
            else : 
                initial_list = list(pareto_no_dupl.keys())
            initial_jobs += 1
        
    result_permutations, lateness, finish = generate_permutations_in_stages_ct(partial_list, A, X, D, P, Q)
    ix0 = np.where(lateness == min(lateness))[0]
    finish0 = finish[ix0]
    ix1 = np.where(finish0 == min(finish0))[0][0]
    iSelect = ix0[ix1]
    if iSelect > len(finish):
        print("Here")
    return result_permutations[iSelect], lateness[iSelect], finish[iSelect]

