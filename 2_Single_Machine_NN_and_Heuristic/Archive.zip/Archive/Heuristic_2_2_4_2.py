import numpy as np
import itertools

# Function to evaluate the lateness and finish time for a given permutation of tasks
def eval_perm_ct_fn(atmp, xtmp, dtmp, ptmp, qtmp):
    ntmp = len(atmp)
    ytmp = np.zeros(ntmp)  # Initialize the list of finish times
    ytmp[0] = atmp[0] + xtmp[0]  # Finish time for the first task
    late = max(ytmp[0] - dtmp[0], 0)  # Calculate the lateness for the first task
    late = qtmp[0] * late + ptmp[0] * (late > 0)  # Calculate the lateness penalty

    # Calculate finish times and lateness penalties for each task
    for k in range(1, ntmp):
        ytmp[k] = max(ytmp[k - 1], atmp[k]) + xtmp[k]  # Finish time of task k
        late_add = max(0, ytmp[k] - dtmp[k])  # Calculate lateness of task k
        late += qtmp[k] * late_add + ptmp[k] * (late_add > 0)  # Add the lateness penalty

    return late, float(ytmp[-1])

# Function to generate initial permutations of tasks
def generate_initial_permutations(partial_list1, J, initial):
    masque = np.isin(partial_list1, list(initial))
    preliminary_order = partial_list1[~masque][:J]
    initial_permutations = []

    for job in preliminary_order:
        remaining_tasks = [task for task in preliminary_order if task != job]
        permutations = itertools.permutations(remaining_tasks, J - 1)

        initial_permutations.extend([initial + (job,) + perm for perm in permutations])

    return initial_permutations

# Function to generate permutations in stages
def generate_permutations_in_stages_ct(partial_list, A, X, D, P, Q):
    result = []
    new_lateness = []
    new_finish = []

    for perm in partial_list:
        penalties, finish_time = eval_perm_ct_fn(A[list(perm)], X[list(perm)], D[list(perm)], P[list(perm)], Q[list(perm)])
        result.append(perm)
        new_lateness.append(penalties)
        new_finish.append(finish_time)

    return np.array(result), np.array(new_lateness), np.array(new_finish)

# Function to select initial permutations with minimum lateness and finish time
def pareto_initial(result_permutations, lateness, finish, taille):
    ix0 = np.where(lateness == min(lateness))[0]
    #finish0 = finish[ix0]
    #ix1 = np.where(finish0 == min(finish0))[0]
    out = np.unique(result_permutations[ix0][:, 0:taille], axis=0)
    return out

# Function to generate permutations sequentially
def sequential(A, X, D, P, Q, partial_list1, J):
    initial = ()
    partial_list = []
    for i in range(len(partial_list1) - (J - 1)):
        if i == 0:
            partial_list = generate_initial_permutations(partial_list1, J, initial)
        else:
            result_permutations, lateness, finish = generate_permutations_in_stages_ct(partial_list, A, X, D, P, Q)
            initials = pareto_initial(result_permutations, lateness, finish, i)
            partial_list = []
            for init in initials:
                initial = tuple(init)
                partial_list += generate_initial_permutations(partial_list1, J, initial)

    return partial_list

# Main function to compute the heuristic
def flow_heurDX_CT2(A, D, X, P, Q):
    A = A.reshape(D.shape)  # Arrival times
    X = X.reshape(D.shape)
    D = D  # Due times
    difference = D
    partial_list1 = np.argsort(difference)
    N = len(difference)  # Number of jobs
    if type(P) != "numpy.ndarray":
        P = P + 0 * A
        Q = Q + 0 * A
    J = 5  # Initial number of tasks to evaluate
    result_permutations, lateness, finish = generate_permutations_in_stages_ct(
        sequential(A, X, D, P, Q, partial_list1, J), A, X, D, P, Q
    )
    ix0 = np.where(lateness == min(lateness))[0]
    finish0 = finish[ix0]
    ix1 = np.where(finish0 == min(finish0))[0][0]
    iSelect = ix0[ix1]
    if iSelect > len(finish):
        print("Here")
    return result_permutations[iSelect], lateness[iSelect], finish[iSelect]

