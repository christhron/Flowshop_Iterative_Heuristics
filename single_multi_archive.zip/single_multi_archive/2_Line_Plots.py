# -*- coding: utf-8 -*-
"""
Created on Sun Oct 22 09:25:53 2023

@author: matth
"""

import numpy as np
import matplotlib.pyplot as plt
import pickle
import time

filename="MachineTimes_Initial.pkl"

joblist=[]

with open(filename, 'rb') as f:
    while True:
        try:
            joblist.append(pickle.load(f))
        except:
            break
        
print(joblist)

#binsize=np.arange(0, jobmachs[3]+dif, dif)

colors=["red","blue","green"]
names=["2 Machines","3 Machines","4 Machines"]
for count in range(3):
    plt.plot(2*np.arange(1,4), np.array(joblist[count*3:count*3+3])/60, marker='o', color=colors[count], label=names[count])
    
    #Add markers
    
plt.yscale("log")
plt.title("Multi-Machine MILP Mean Runtimes")
plt.legend()
    #ax2.set_xlim(xmin=-5,xmax=5)
    #ax2.set_ylim(ymin=0,ymax=10)
    #plt.xlabel("Percent Difference (Bin Size=" + str(binw) + ")")
plt.ylabel("Time (Minutes)")
plt.xlabel("Number of Jobs")
#plt.ylim(0,0.1)
plt.xticks([2,4,6])
plt.show()