# -*- coding: utf-8 -*-


import pickle
import numpy as np
import statistics as st
from matplotlib import pyplot as plt
from Functions.FlowshopBaseSchedRoutines import Obj_pq
from Functions.Heuristics.Pareto_Heuristics import flow_heurDX_CT_best, flow_heurDX_CT1
from Functions.Heuristics.Dispatch_Heuristics import Best_order
from Functions.Heuristic_v4_CT import *
import time
from math import *
import pandas as pd

# Paths to training/validation data and testing data respectively
dataFilePaths = ["Data/single_machine_6N.pickle", "Data/single_machine_8N.pickle","Data/single_machine_10N.pickle","Data/single_machine_12N.pickle", "Data/single_machine_14N.pickle"]
#dataFilePath = 'C:/Users/USER/My Drive/teaching/Spring2023/Matt/Codes/1_MILP_exact_single_and_multi_machine_algorithms/single_machine_examples.pickl
saveFile = ['singleMachineModel_6N.pickle','singleMachineModel_8N.pickle','singleMachineModel_10N.pickle','singleMachineModel_12N.pickle','singleMachineModel_14N.pickle']
saveModel = False
# Number of jobs
Ns=[6,8,10,12,14]
# Lateness for objective function: penalty & rate
p=50
q=1
nb_instances = [10000,10000,10000,10000,10000]
runtimes_vectors = []
accuracys_vectors = []
mean_difference_vectors = []
difference_vectors = []
max_differerence_vectors  = []
std_difference_vectors  = []
### Compute the start and finish times based on system parameters and the given job order (copied from MILP code, and simplified to only do 1 machine)
def CalcYS(m0,job,Am0,X,Z):
    N,M=X.shape
    #Starting time(S) and finishing time(Y)
    S=np.empty((N,M))
    Y=np.empty((N,M))
    Idle =np.empty((N,M))

    j=int(job[0,m0])
    # First Stage:
    S[j,m0]=Am0[j]+Z[j,m0]
    Y[j,m0]=S[j,m0]+X[j,m0]
    Idle[j,m0] = 0

    for jn in range(1,N):
        j=int(job[jn,m0])
        S[j,m0]=max(Am0[j]+Z[j,m0],Y[int(job[jn-1,m0]),m0])
        Y[j,m0]=S[j,m0]+X[j,m0]
        Idle[j,m0] = S[j,m0]-Y[int(job[jn-1,m0]),m0]
        
    return Y,S,Idle





#print("Total instances :",nb_instances )
for file in  range(len(dataFilePaths)):
    all_arrival=[]
    all_work=[]
    all_due=[]
    all_labels=[]
    # Save scale factors(to compute objective function)
    all_scale = []
    dataFilePath = dataFilePaths[file]
    N = Ns[file]
    with open(dataFilePath, 'rb') as f:
        while True:
            try:
                data = pickle.load(f)
                #scale per instance so max due  time =1
                scale = 1#np.max(data['D'])
                all_scale.append(scale)
                all_arrival.append(data['A']/scale) 
                all_work.append(data['X']/scale)
                all_due.append(data['D']/scale)
                label=np.zeros([1,N])
                label[0]=data['order']
               # label[1]=scale
                all_labels.append(label)
            except EOFError:
                # Reached the end of the file
                break
    all_scale = np.array(all_scale)
    all_labels=np.squeeze(all_labels, axis=1)
    
    instance=np.zeros([3,N])
    inputs=np.zeros([len(all_arrival),3,N])
    for i in range(len(all_arrival)):
        instance[0]=all_arrival[i]
        instance[1]=all_work[i].flatten()
        instance[2]=all_due[i]
        
        inputs[i]=instance ########################################
    x_test,y_test = inputs, all_labels
    
    # Count of accurate objective predictions and arrays for objective values of NN, MILP, and random for comparison
    count=0
    n_test = nb_instances[file]
    objr=np.zeros(n_test) #MILP
    objHeur4=np.zeros(n_test) #Heuristic2.2.4 best
    objOrder=np.zeros(n_test) #In Order
    objHeur=np.zeros(n_test) #Initial Heuristic
    objHeur1=np.zeros(n_test) #Heuristic2.2.4_1
    objHeur2=np.zeros(n_test) #Heuristic2.2.4_2
    runtimes_vector = []
    accuracys_vector = []
    execution_time_heur_2_2_4,execution_time_heur_2_2_4_1,execution_time_heur_2_2_4_2, execution_time_heur_2_2_4_best,execution_time_greedy = 0,0,0,0,0

   # with open(saveFile[file], 'wb') as f:
    for i in range(n_test):
                scale=1 #y_test[i][1,0]
                A=np.array(x_test[i,0]).reshape([1,N])#(scale*x_test[i][0]).reshape([N,1])
                X=np.array(scale*x_test[i][1]).reshape([1,N])
                D=np.array(x_test[i,2]).reshape([1,N])#(scale*x_test[i][2])#.reshape([N,1])
                
                label= np.array(y_test[i]) 
                
                samp=np.append(np.append(A, X, axis=0), D, axis=0)
                D=D.flatten()
                
        
                # Prediction from MILP
                realY, realS, realIdle=CalcYS(0, label.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
                
                # Prediction for greedy (in arrival order)
                # This can be used as baseline
                start_time3 = time.time()
                GreedyOders = np.arange(N)
                end_time3 = time.time()
                execution_time_greedy += end_time3 - start_time3
               
                # Prediction from Heuristic 2.2.4 initial order (D - X)
                start_time = time.time()
                HeurOrders, Heur_late_totals, Heur_fin_totals=flow_heurDX_CT(A,D,X,p,q)
                end_time = time.time()
                execution_time_heur_2_2_4 += end_time - start_time
                
                # Prediction from Heuristic 2.2.4 initial order (A)
                start_time1 = time.time()
                HeurOrders1, Heur_late_totals1, Heur_fin_totals1=flow_heurDX_CT1(A,D,X,p,q,1)
                end_time1 = time.time()
                execution_time_heur_2_2_4_1 += end_time1 - start_time1
                
                # Prediction from Heuristic 2.2.4 initial order (D)
                start_time2 = time.time()
                HeurOrders2, Heur_late_totals2, Heur_fin_totals2=flow_heurDX_CT1(A,D,X,p,q,2)
                end_time2 = time.time()
                execution_time_heur_2_2_4_2 += end_time2 - start_time2
                
                
                # Prediction from Heuristic 2.2.4 best
                start_time4 = time.time()
                HeurOrders4, Heur_late_totals4, Heur_fin_totals4=flow_heurDX_CT_best(A,D,X,p,q)
                end_time4 = time.time()
                execution_time_heur_2_2_4_best += end_time4 - start_time4

                
                heurY, heurS, heurIdle=CalcYS(0, HeurOrders.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
                heurY1, heurS1, heurIdle1=CalcYS(0, HeurOrders1.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
                heurY2, heurS2, heurIdle2=CalcYS(0, HeurOrders2.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
                heurY4, heurS4, heurIdle4=CalcYS(0, HeurOrders4.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
                ordY, ordS, ordIdle=CalcYS(0, np.arange(N).reshape([N,1]), A.T, X.T, np.zeros([N,1]))
                
                
                objr[i]=Obj_pq(D,realY,p,q)
                objOrder[i]=Obj_pq(D,ordY,p,q)
                objHeur4[i]=Obj_pq(D,heurY4,p,q)
                objHeur2[i]=Obj_pq(D,heurY2,p,q)
                objHeur1[i]=Obj_pq(D,heurY1,p,q)
                objHeur[i]=Obj_pq(D,heurY,p,q)
                
                # list of orders 
                #orders = [label,HeurOrders,HeurOrders1,HeurOrders2,HeurOrders4,GreedyOders]
                # list of objectives
               # objectives = [objr,objHeur,objHeur1,objHeur2,objHeur4,objOrder]
              #  save ={'A':A,'X':X,'D':D,'p':p, 'q':q,'orders':orders,'objectives':objectives }
                # save results
                #pickle.dump(save, f)
  
    runtimes_vector = [execution_time_heur_2_2_4 / n_test, execution_time_heur_2_2_4_1/ n_test, execution_time_heur_2_2_4_2 / n_test, execution_time_heur_2_2_4_best/n_test, execution_time_greedy/ n_test] 
    accuracys_vector = [sum(objHeur<=objr)/ n_test*100, sum(objHeur1<=objr)/ n_test*100, sum(objHeur2<=objr)/ n_test*100, sum(objHeur4<=objr)/ n_test*100 ,sum(objOrder<=objr)/ n_test*100] 
    max_differerence_vector = [max(objHeur-objr), max(objHeur1-objr), max(objHeur2-objr),max(objHeur4-objr), max(objOrder-objr)]
    mean_difference_vector = [np.mean(objHeur-objr), np.mean(objHeur1-objr), np.mean(objHeur2-objr),np.mean(objHeur4-objr),np.mean(objOrder-objr)]
    difference_vector = [(objHeur-objr), (objHeur1-objr), (objHeur2-objr),(objHeur4-objr),(objOrder-objr)]

    std_difference_vector = [ st.stdev(objHeur-objr),  st.stdev(objHeur1-objr),  st.stdev(objHeur2-objr), st.stdev(objHeur4-objr), st.stdev(objOrder-objr)]
    
    runtimes_vectors.append(runtimes_vector)
    accuracys_vectors.append(accuracys_vector)
    max_differerence_vectors.append(max_differerence_vector)
    mean_difference_vectors.append(mean_difference_vector)
    difference_vectors.append(difference_vector)
    std_difference_vectors.append(std_difference_vector)

    
runtimes_vectors = np.array(runtimes_vectors).T 
accuracys_vectors =  np.array(accuracys_vectors).T 
max_differerence_vectors = np.array(max_differerence_vectors).T
difference_vectors = np.array(difference_vectors)
mean_difference_vectors = np.array(mean_difference_vectors).T
std_difference_vectors = np.array(std_difference_vectors).T


# Define colors
colors = ['green','orange', 'purple', 'red','blue']
methods = ['Initial Heuristic order (D - X)', 'Heuristic 2.2.4 initial order (A)', 'Heuristic 2.2.4 initial order (D)','Heuristic 2.2.4 Best','Greedy (in arrival order)']
names = ["6 jobs", "8 jobs", "10 jobs", "12 jobs", "14 jobs"]
# Plotting

fig, ax = plt.subplots(figsize=(10, 6))

for i in range(runtimes_vectors.shape[0]):
    # Convert number of jobs to integers for proper spacing
    x = np.arange(1, len(names) + 1)

    # Plot each line
    ax.plot(x, runtimes_vectors[i], marker='o', color=colors[i], label=methods[i])

ax.set_title('Execution Time per instances')
ax.set_xlabel('Number of Jobs')
ax.set_ylabel('Time (seconds)')
ax.set_xticks(x)
ax.set_xticklabels(names)
ax.legend()

plt.tight_layout()
plt.show()


# Calculate standard deviations

std_devs = (((accuracys_vectors/100) * (1 - (accuracys_vectors/100))) / nb_instances[0]) *100

# Plotting
fig, ax = plt.subplots(figsize=(10, 6))

for i in range(accuracys_vectors.shape[0] - 1):
    # Convert number of jobs to integers for proper spacing
    x = np.arange(1, len(names) + 1)

    # Plot each line with error bars
    ax.errorbar(x, accuracys_vectors[i], yerr=2*std_devs[i], fmt='o', color=colors[i], label=methods[i])

    ax.plot(x, accuracys_vectors[i], marker='o', color=colors[i])

ax.set_title('Objective Accuracy (%) for ' + str(nb_instances[0]) + ' instances')
ax.set_xlabel('Number of Jobs')
ax.set_ylabel('Accuracy')
ax.set_xticks(x)
ax.set_xticklabels(names)
ax.legend()

plt.tight_layout()
plt.show()

fig, ax = plt.subplots(figsize=(10, 6))

i =(accuracys_vectors.shape[0]- 1)
# Convert number of jobs to integers for proper spacing
x = np.arange(1, len(names) + 1)

# Plot each line with error bars
ax.errorbar(x, accuracys_vectors[i], yerr=2*std_devs[i], fmt='o', color=colors[i], label=methods[i])

ax.plot(x, accuracys_vectors[i], marker='o', color=colors[i])

ax.set_title('Objective Accuracy (%) for ' + str(nb_instances[0]) + ' instances')
ax.set_xlabel('Number of Jobs')
ax.set_ylabel('Accuracy')
ax.set_xticks(x)
ax.set_xticklabels(names)
ax.legend()

plt.tight_layout()
plt.show()


fig, ax = plt.subplots(figsize=(10, 6))

for i in range(std_difference_vectors.shape[0] - 1):
    # Convert number of jobs to integers for proper spacing
    x = np.arange(1, len(names) + 1)

    # Plot each line
    ax.plot(x, std_difference_vectors[i], marker='o', color=colors[i], label=methods[i])

ax.set_title('Standard deviation of Objective Difference for ' + str(nb_instances[0]) + ' instances')
ax.set_xlabel('Number of Jobs')
ax.set_ylabel('Standard deviation')
ax.set_xticks(x)
ax.set_xticklabels(names)
ax.legend()

plt.tight_layout()
plt.show()
fig, ax = plt.subplots(figsize=(10, 6))
i = std_difference_vectors.shape[0] -1
# Convert number of jobs to integers for proper spacing
x = np.arange(1, len(names) + 1)

# Plot each line
ax.plot(x, std_difference_vectors[i], marker='o', color=colors[i], label=methods[i])

ax.set_title('Standard deviation of Objective Difference for ' + str(nb_instances[0]) + ' instances')
ax.set_xlabel('Number of Jobs')
ax.set_ylabel('Standard deviation')
ax.set_xticks(x)
ax.set_xticklabels(names)
ax.legend()

plt.tight_layout()
plt.show()

fig, ax = plt.subplots(figsize=(10, 6))

for i in range(mean_difference_vectors.shape[0] - 1 ):
    # Convert number of jobs to integers for proper spacing
    x = np.arange(1, len(names) + 1)

    # Plot each line
    ax.plot(x, mean_difference_vectors[i], marker='o', color=colors[i], label=methods[i])

ax.set_title('Average Objective Difference for ' + str(nb_instances[0]) + ' instances')
ax.set_xlabel('Number of Jobs')
ax.set_ylabel('Average Objective Difference')
ax.set_xticks(x)
ax.set_xticklabels(names)
ax.legend()

plt.tight_layout()
plt.show()
fig, ax = plt.subplots(figsize=(10, 6))
i = mean_difference_vectors.shape[0] - 1 
# Convert number of jobs to integers for proper spacing
x = np.arange(1, len(names) + 1)

# Plot each line
ax.plot(x, mean_difference_vectors[i], marker='o', color=colors[i], label=methods[i])

ax.set_title('Average Objective Difference for ' + str(nb_instances[0]) + ' instances')
ax.set_xlabel('Number of Jobs')
ax.set_ylabel('Average Objective Difference')
ax.set_xticks(x)
ax.set_xticklabels(names)
ax.legend()

plt.tight_layout()
plt.show()






percentiles = [90, 95, 99]
linestyles = ['-', '--', ':']
fig, ax = plt.subplots(figsize=(10, 6))
for method_idx in range(len(methods) - 1):
    data_method = difference_vectors[:,method_idx,:]
    data_method = np.sort(data_method, axis=1)
    

    nom_methode = methods[method_idx]
    couleur = colors[method_idx]

    for percentile, style_ligne in zip(percentiles, linestyles):
        valeur_percentile = np.percentile(data_method, percentile, axis=1)


        ax.plot(range(1, len(names) + 1), valeur_percentile, marker='o', linestyle=style_ligne, color=couleur,
                label=f"{nom_methode} - {percentile}e percentile")

ax.set_title('Percentiles Objective Difference for ' + str(nb_instances[0]) + ' instances')
ax.set_xlabel('Nombre de tâches')
ax.set_ylabel('Différence')
ax.set_xticks(np.arange(1, len(names) + 1))
ax.set_xticklabels(names)
ax.legend()

plt.tight_layout()
plt.show()

fig, ax = plt.subplots(figsize=(10, 6))
method_idx = len(methods) - 1
data_method = difference_vectors[:,method_idx,:]
data_method = np.sort(data_method, axis=1)
    


nom_methode = methods[method_idx]
couleur = colors[method_idx]

for percentile, style_ligne in zip(percentiles, linestyles):
    valeur_percentile = np.percentile(data_method, percentile, axis=1)


    ax.plot(range(1, len(names) + 1), valeur_percentile, marker='o', linestyle=style_ligne, color=couleur,
            label=f"{nom_methode} - {percentile}e percentile")

ax.set_title('Percentiles Objective Difference for ' + str(nb_instances[0]) + ' instances')
ax.set_xlabel('Nombre de tâches')
ax.set_ylabel('Différence')
ax.set_xticks(np.arange(1, len(names) + 1))
ax.set_xticklabels(names)
ax.legend()

plt.tight_layout()
plt.show()

methods = ['initial order (D - X)', 'initial order (A)', 'initial order (D)','Best','Greedy']
data_runtime = pd.DataFrame(data = runtimes_vectors, columns = names, index = methods )
data_runtime.index.name = "runtimes"
data_accuracys = pd.DataFrame(data = accuracys_vectors, columns = names, index = methods)
data_accuracys.index.name = "accuracys"
print("Objective Accuracy (%)")

print(data_accuracys)
print('\nExecution Time per instances')
display(data_runtime)

