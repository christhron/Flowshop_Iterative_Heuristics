# -*- coding: utf-8 -*-
"""
Created on Sun Nov 12 14:39:04 2023

@author: matth
"""

from FlowshopProblemClassDefs import *
from FlowshopProblemCreationRoutines_v1 import *
from FlowshopMILPschedRoutines import *
from scipy.optimize import linprog
from itertools import permutations
import numpy as np
import matplotlib.pyplot as plt
import pickle
import time

pickleFilename = 'heuristic_6N.pickle'
writeToPickle=True

# Number of instances generated
nInstances=15000

N_jobs,M_stage,K_sen,mu_Ar,mu_Ai,mu_Dint=6,1,1,5,1E10,10

    #Flat rate:
p=50
    #Rate penalty:
q=1
   
# Parameters for randomly generating a scheduling scenario
Mu_mu_Xm=np.ones((1,M_stage))*5
Mu_sigma_Xm=np.ones((1,M_stage))*0.0001 # Remove uncertainty
Mu_mu_Zm=np.ones((1,M_stage))*5# 
Mu_sigma_Zm=np.ones((1,M_stage))*0.0001 # Remove uncertainty
uncertainFlag=False

### Function to create near-optimal job orders by successive insertion
# initial_list:  Jobs already specified in order (typically start with 1 job)
# remaining_orders: jobs to insert, in order of insertion
def generate_permutations_in_stages(initial_list, remaining_orders, A, X, D):
    result = [initial_list.copy()]# result is used to list all saved orders
    # all_permutations = [initial_list.copy()]

    lateness_list = [0]  # Initialize with lateness of the initial list
    finish_list = [(A + X)[initial_list[0]]]  # Initialize with finishing time of the initial list

    # Run for each job not yet included
    for order in remaining_orders:
        new_permutations = []
        new_lateness = []
        new_finish = []

        # For each saved job order from the last stage, run the insertion permutations
        for i, permuted_list in enumerate(result):
            #print("Now trying permutations onto: ",permuted_list)
            for j in range(len(permuted_list) + 1):
                # new_permutation = permuted_list[:j] + [order] + permuted_list[j:]
                new_permutation = permuted_list.copy()                
                new_permutation.insert(j,order)
                print("\tNew_Permutation: ",new_permutation)
                
                # Calculate lateness and finishing time for the new permutation
                Arr = A[new_permutation]
                Xecute = X[new_permutation]
                Dues = D[new_permutation]
                late = 0
                Y = np.empty(Xecute.shape)
                Y[0] = Arr[0] + Xecute[0]
                late = max(Y[0] - Dues[0], 0)
                for k in range(1, len(new_permutation)):
                    Y[k] = max(Y[k - 1], Arr[k]) + Xecute[k]
                    late = late + max(0, Y[k] - Dues[k])# @@@ include p* number_late + q* lateness

                # Check conditions for saving or deleting permutations
                save = True
                delete = []
                for i in range(len(new_permutations)):
                    # @@@ switch order of checking conditions
                    if (
                        (new_lateness[i] >= late and new_finish[i] >= Y[-1])
                    ):
                        delete.append(i)
                    elif (new_lateness[i] <= late and new_finish[i] <= Y[-1]):
                        #print("\t\tNot saving")
                        save=False
                        break

                # Save permutations
                if save:
                    new_permutations.append(new_permutation)
                    new_lateness.append(late)
                    new_finish.append(Y[-1])
                    for j in range(len(delete)-1,-1,-1):
                        # j=len(delete)-1-i
                        #print("\t\tDeleting order: ",new_permutations[delete[j]])
                        del new_permutations[delete[j]]
                        del new_lateness[delete[j]]
                        del new_finish[delete[j]]

        # Prepare for the next stage
        # @@@ do we need 'copy' here?
        result = new_permutations
        # all_permutations.extend(new_permutations)
        lateness_list.extend(new_lateness)
        finish_list.extend(new_finish)

    return new_permutations, new_lateness, new_finish

# Sort by arrival
def flow_heurA(A,D,X,P,Q):
  A= A.reshape(D.shape) #arrival times
  X= X.reshape(D.shape)
  D= D #due times
  #X= X.reshape(D.shape) #processing times
  #P= lateness penalty
  #Q= lateness charge rate
  N=len(A) #Number of jobs
  if type(P)!="numpy.ndarray":
    P=P+0*A
    Q=Q+0*A

    # Holds the order
  order=np.zeros(N)
    # All jobs not yet ordered
  jobs=np.array(range(N))
    # A+X as updated
  temp=A+X
    # Current finishing time
  fin=0
  for i in range(N):
      # Find fastest job under current conditions
      temp=A[jobs]+X[jobs]-fin
      #print(temp)
      #print(jobs)
      fin=np.min(temp)
      j_curr=np.where(temp==fin)
      # Save & update arrays
      order[i]=jobs[j_curr]
      jobs=np.delete(jobs,j_curr)
  return order

# Sort by relative due time
def flow_heurDX(A,D,X,P,Q):
  A= A.reshape(D.shape) #arrival times
  X= X.reshape(D.shape)
  D= D #due times
  Due=D-X
  N=len(Due) #Number of jobs
  if type(P)!="numpy.ndarray":
    P=P+0*A
    Q=Q+0*A

    # Holds the order
  order=np.argsort(Due)
  
      # orderPartial= list of job orders that are already determined
      
  orderPartial=[order[0]]
  
  #, lateness= list of lateness for saved orders, finish= finishing time of those orders
  result_permutations, lateness, finish = generate_permutations_in_stages(orderPartial, order[1:], A, X, D)

  for i in range(len(result_permutations)):
    permuted_list = result_permutations[i]
    late = lateness[i]
    finish_time = finish[i]
    print(f"Order: {permuted_list}, Lateness: {late}, Finish Time: {finish_time}")
    #print(" ")
  return result_permutations, lateness, finish

# Arrange final generated list by finishing time
def fastOrd (orders, lateness, finish):
    orders=np.array(orders)
    lateness=np.array(lateness)
    finish=np.array(finish)
    
    # Get the indices that would sort the finish array
    sorted_indices = np.argsort(finish)

    # Use the sorted indices to reorder the other lists
    sorted_orders = orders[sorted_indices]
    sorted_lateness = lateness[sorted_indices]
    sorted_finish = finish[sorted_indices]
    
    return sorted_orders, sorted_lateness, sorted_finish

# Arrange final generated list by lateness
def tempoOrd (orders, lateness, finish):
    orders=np.array(orders)
    lateness=np.array(lateness)
    finish=np.array(finish)
    
    # Get the indices that would sort the finish array
    sorted_indices = np.argsort(lateness)

    # Use the sorted indices to reorder the other lists
    sorted_orders = orders[sorted_indices]
    sorted_lateness = lateness[sorted_indices]
    sorted_finish = finish[sorted_indices]
    
    return sorted_orders, sorted_lateness, sorted_finish

# order by lateness (first key) and then by finish time (second key)
# @@@ This may no longer be necessary, because there will not be more than one solution with the same lateness
def fastTempo (orders, lateness, finish):
    orders=np.array(orders)
    lateness=np.array(lateness)
    finish=np.array(finish)
    
    # Get unique lateness values
    unique_lateness_values = np.unique(lateness)

    sorted_orders = []
    sorted_lateness = []
    sorted_finish = []

    for lateness_value in unique_lateness_values:
        # Find indices where lateness equals the current unique value
        indices = np.where(lateness == lateness_value)[0]

        # Find the index with the minimum finish time among those indices
        min_finish_index = indices[np.argmin(finish[indices])]

        # Append the trio with the minimum finish time to the sorted lists
        sorted_orders.append(orders[min_finish_index])
        sorted_lateness.append(lateness[min_finish_index])
        sorted_finish.append(finish[min_finish_index])

    return np.array(sorted_orders), np.array(sorted_lateness), np.array(sorted_finish)

#----------------------------------------------------------------------------------------------------#
# Set up classes for parameters
params=Params(M_stage,N_jobs,K_sen,mu_Ar,mu_Ai,mu_Dint,Mu_mu_Xm,Mu_sigma_Xm,Mu_mu_Zm,Mu_sigma_Zm)

# Save to existing pickle file
with open(pickleFilename, 'wb') as f:
    if writeToPickle:
        pickle.dump(nInstances, f)
    beg=time.time()
    for i in range(nInstances): 
        start=time.time()
        print("Instance no. ",i+1)
        [Vec,indVec,mu_X,sigma_X,mu_Z,sigma_Z]=Create_inst(params, uncertainFlag)    
 
        A = Vec.A[:,0]; D=Vec.D[:,0]; X=Vec.X[:,:,0]; 
        orders, late_totals, fin_totals=flow_heurDX(A,D,X,p,q)
        end=time.time()
    
        timer=end-start
        instance={'A':A,'X':X,'D':D,'order':orders, 'lateness':late_totals, "finishing":fin_totals, "time":timer, 'p':p, 'q':q}
   
        if writeToPickle:
            pickle.dump(instance, f)
        print("This instance took: ", end-start, " seconds")
    print("This took: ", end-beg, " seconds for ", nInstances, " instances")
    if writeToPickle:
        pickle.dump(end-beg, f)