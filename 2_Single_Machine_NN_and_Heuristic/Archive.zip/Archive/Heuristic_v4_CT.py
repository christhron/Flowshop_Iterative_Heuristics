# -*- coding: utf-8 -*-
"""
Created on Sun Nov 12 14:39:04 2023

@author: matth
"""

#from FlowshopProblemClassDefs import *
#from FlowshopProblemCreationRoutines_v1 import *
#from FlowshopMILPschedRoutines import *
#from FlowshopBaseSchedRoutines import *
#from scipy.optimize import linprog
from itertools import permutations
import numpy as np
#import matplotlib.pyplot as plt
import pickle
import time

# "This version loads in MILP data for comparison. The 6N instances are saved correctly; other MILP instances are not."

# pickleFilename = 'heuristic_v_MILP_8N.pickle'
# dataFilename="single_machine_8N.pickle"
# writeToPickle=True

# # Number of instances generated
# nInstances=12000

# N_jobs,M_stage,K_sen,mu_Ar,mu_Ai,mu_Dint=8,1,1,5,1E10,10

#     #Flat rate:
# p=50
#     #Rate penalty:
# q=1
   
# # Parameters for randomly generating a scheduling scenario
# Mu_mu_Xm=np.ones((1,M_stage))*5
# Mu_sigma_Xm=np.ones((1,M_stage))*0.0001 # Remove uncertainty
# Mu_mu_Zm=np.ones((1,M_stage))*5# 
# Mu_sigma_Zm=np.ones((1,M_stage))*0.0001 # Remove uncertainty
# uncertainFlag=False

def evalPermCT_fn(Atmp, Xtmp, Dtmp, Ptmp, Qtmp):
    nTmp = len(Atmp)
    # Y will hold finish times
    Ytmp = np.zeros(nTmp)
    # Finish time of first job
    Ytmp[0] = Atmp[0] + Xtmp[0]
    # Late penalty of first job
    late = max(Ytmp[0] - Dtmp[0], 0)
    late = Qtmp[0]*late + Ptmp[0]*(late>0)
    
    # Calculate finish times and late penalties of jobs one by one
    for k in range(1, nTmp):
        # Finish time of k'th job
        Ytmp[k] = max(Ytmp[k - 1], Atmp[k]) + Xtmp[k]
        # Late penalty of k'th job
        late_add = max(0, Ytmp[k] - Dtmp[k])
        late = late + Qtmp[k]*late_add + Ptmp[k]*(late_add>0)
    return late,float(Ytmp[-1])


def pruneList_fn(tmp_lateness, tmp_finish,tmp_perms):
    late_compare_gt = (tmp_lateness.reshape((1,-1))>tmp_lateness.reshape((-1,1))).astype(int)
    finish_compare_gt = (tmp_finish.reshape((1,-1))>tmp_finish.reshape((-1,1))).astype(int)
    
    index_remove_mx = (late_compare_gt * finish_compare_gt) 
    ix = (np.sum(index_remove_mx,axis=0)==0)
    return ix

def generate_permutations_in_stages_CT(partial_list, A, X, D, P, Q):
    job0 = partial_list[0]  
    remaining_jobs = partial_list[1:]

    result = np.array([[partial_list[0]]])
    length=1 #starting length of  partial_lists

    
    # Run for each job not yet included in the starting partial_list
    for next_job in remaining_jobs:
        length=length+1#
        new_perms = np.zeros((len(result)*length, length), dtype=int)
        new_lateness = np.zeros(len(result)*length)
        new_finish = np.zeros(len(result)*length)

        # For each saved partial_list from the last stage, run the insertion permutations
        for i, partial_list in enumerate(result):
            for j in range(length):
                nn =  j+length*i
                new_perm = np.insert(partial_list, j, next_job)
                new_perms[nn,:]=new_perm
                # Calculate lateness and finishing time for the new permutation
                # Define ordered subarrays for the calculation, in agreement with the current permutation
                new_lateness[nn], new_finish[nn] \
                    = evalPermCT_fn(A[new_perm],X[new_perm],
                                    D[new_perm],P[new_perm],Q[new_perm])
                
                
        # Prune list to keep only Pareto optimal orderings.
        ix = pruneList_fn(new_lateness, new_finish,new_perms)
        result = new_perms[ix,:]
        print("Number retained",len(result))

    return result, new_lateness[ix], new_finish[ix]

# Sort by relative due time
def flow_heurDX_CT(A,D,X,P,Q):
  A= A.reshape(D.shape) #arrival times
  X= X.reshape(D.shape)
  D= D #due times
  Due=D-X
  N=len(Due) #Number of jobs
  if type(P)!="numpy.ndarray":
    P=P+0*A
    Q=Q+0*A

    # Holds the partial_list
  partial_list=np.argsort(Due)
  
      # partial_listPartial= list of job partial_lists, lateness= list of lateness for each of those partial_lists, finish= finishing time of those partial_lists
  
  result_permutations, lateness, finish = generate_permutations_in_stages_CT(partial_list, A, X, D, P, Q)
  
  # Select perms. with minimum lateness
  ix0 = np.where(lateness==min(lateness))[0]
  # Get finish times for these permutations
  finish0 = finish[ix0]
  # Select first permutation with minium finish time
  ix1 = np.where(finish0==min(finish0))[0][0]
  iSelect = ix0[ix1]
  if iSelect>len(finish):
      print("Here")
  
  return result_permutations[iSelect], lateness[iSelect], finish[iSelect]
