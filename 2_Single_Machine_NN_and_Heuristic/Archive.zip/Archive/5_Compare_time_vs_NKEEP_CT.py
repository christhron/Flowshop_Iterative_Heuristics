# -*- coding: utf-8 -*-


import pickle
import numpy as np
import statistics as st
from matplotlib import pyplot as plt
from Functions.FlowshopBaseSchedRoutines import Obj_pq
import Functions.Heuristic_v4_CT as hv4
import Functions.Heuristics.Pareto_Heuristics as hSelect
import time
from math import *

# Paths to training/validation data and testing data respectively
dataFilePaths = ["Data/single_machine_50N_100int.pickle"]#, "Data/single_machine_8N.pickle","Data/single_machine_10N.pickle", "Data/single_machine_12N.pickle","Data/single_machine_14N.pickle","Data/single_machine_16N.pickle","Data/single_machine_18N.pickle","Data/single_machine_20N.pickle"]#,"Data/single_machine_450N.pickle","Data/single_machine_500N.pickle"] 
#dataFilePath = 'C:/Users/USER/My Drive/teaching/Spring2023/Matt/Codes/1_MILP_exact_single_and_multi_machine_algorithms/single_machine_examples.pickl
saveFile = ['singleMachineModel_50N_CT.pickle','singleMachineModel_100N_CT.pickle']
saveModel = False
# Number of jobs
Ns=[50]#,    6,8,10,12,14,16,18,20]#,450,500]  
Ks=np.array([30, 40, 50, 60, 70, 80])#,100,120,140,160,180,200,450,500] 
numIns=np.array([3,4,5,6,7]) 
# Lateness for objective function: penalty & rate
p=50
q=1
nb_instances = [100]#00,10000,10000,10000,10000,10000,10000,10000]#,10,10,10,10]#
runtimes_vector = np.zeros([len(Ks),len(numIns)])
accuracys_vectors = np.zeros([len(Ks),len(numIns)])
mean_difference_vectors = np.zeros([len(Ks),len(numIns)])
difference_vectors = np.zeros([len(Ks),len(numIns),nb_instances[0]])
max_differerence_vectors  = np.zeros([len(Ks),len(numIns)])
std_difference_vectors  = np.zeros([len(Ks),len(numIns)])
objHeur10s=np.zeros([len(Ks),nb_instances[0]])
objHeur15s=np.zeros([len(Ks),nb_instances[0]])
objHeur20s=np.zeros([len(Ks),nb_instances[0]])
objHeur30s=np.zeros([len(Ks),nb_instances[0]])
objHeur35s=np.zeros([len(Ks),nb_instances[0]])
total_runtimes=np.zeros([len(numIns),len(Ks),nb_instances[0]])
### Compute the start and finish times based on system parameters and the given job order (copied from MILP code, and simplified to only do 1 machine)
def CalcYS(m0,job,Am0,X,Z):
    N,M=X.shape
    #Starting time(S) and finishing time(Y)
    S=np.empty((N,M))
    Y=np.empty((N,M))
    Idle =np.empty((N,M))

    j=int(job[0,m0])
    # First Stage:
    S[j,m0]=Am0[j]+Z[j,m0]
    Y[j,m0]=S[j,m0]+X[j,m0]
    Idle[j,m0] = 0

    for jn in range(1,N):
        j=int(job[jn,m0])
        S[j,m0]=max(Am0[j]+Z[j,m0],Y[int(job[jn-1,m0]),m0])
        Y[j,m0]=S[j,m0]+X[j,m0]
        Idle[j,m0] = S[j,m0]-Y[int(job[jn-1,m0]),m0]
        
    return Y,S,Idle

with open('Output/timeVsNKEEP_50N_Insertion.pkl','rb') as file:
        runtimes_vectorsI=pickle.load(file)
        accuracys_vectorsI=pickle.load(file)
        max_differerence_vectorsI=pickle.load(file)
        mean_difference_vectorsI=pickle.load(file)
        difference_vectorsI=pickle.load(file)
        std_differenceI_vectors=pickle.load(file)
        execution_time_heur10I=pickle.load(file)
        execution_time_heur20I=pickle.load(file)
        execution_time_heur30I=pickle.load(file)
        execution_time_heur35I=pickle.load(file)
        total_runtimesI=pickle.load(file)
        objHeur10sI=pickle.load(file)
        objHeur15sI=pickle.load(file)
        objHeur20sI=pickle.load(file)
        objHeur30sI=pickle.load(file)
        objHeur35sI=pickle.load(file)
        objHeurMin=pickle.load(file)



#print("Total instances :",nb_instances )
for file in  range(len(dataFilePaths)):
    all_arrival=[]
    all_work=[]
    all_due=[]
    all_labels=[]
    # Save scale factors(to compute objective function)
    all_scale = []
    dataFilePath = dataFilePaths[file]
    N = Ns[file]
    with open(dataFilePath, 'rb') as f:
        while True:
            try:
                data = pickle.load(f)
                #scale per instance so max due  time =1
                scale = 1#np.max(data['D'])
                all_scale.append(scale)
                all_arrival.append(data['A']/scale) 
                all_work.append(data['X']/scale)
                all_due.append(data['D']/scale)
                label=np.zeros([1,N])
                label[0]=data['order']
               # label[1]=scale
                all_labels.append(label)
            except EOFError:
                # Reached the end of the file
                break
    all_scale = np.array(all_scale)
    all_labels=np.squeeze(all_labels, axis=1)
    
    instance=np.zeros([3,N])
    inputs=np.zeros([len(all_arrival),3,N])
    for i in range(len(all_arrival)):
        instance[0]=all_arrival[i]
        instance[1]=all_work[i].flatten()
        instance[2]=all_due[i]
        
        inputs[i]=instance ########################################
    x_test,y_test = inputs, all_labels

for j in range(len(Ks)):
    hv4.NKEEP=Ks[j]
    hSelect.NKEEP=Ks[j]
    # Count of accurate objective predictions and arrays for objective values of NN, MILP, and random for comparison
    count=0
    n_test = nb_instances[file]
    objr=np.zeros(n_test) #MILP

    #objHeur=np.zeros(n_test) #Heuristic
    # Sewa Heuristic
    objHeurBest=np.zeros(n_test) 
    # Heuristic keep 10, 20, 30, 40, 50
    objHeur10, objHeur15, objHeur20, objHeur30, objHeur35 = np.zeros(n_test), np.zeros(n_test), np.zeros(n_test), np.zeros(n_test), np.zeros(n_test)
    # Best obj value
    objHeurMin = np.zeros(n_test)

    accuracys_vector = []

    execution_time_heur10, execution_time_heur15, execution_time_heur20, execution_time_heur30, execution_time_heur35 = np.zeros(nb_instances[0]),np.zeros(nb_instances[0]),np.zeros(nb_instances[0]),np.zeros(nb_instances[0]),np.zeros(nb_instances[0])


    for i in range(nb_instances[0]):
            
        
            scale=1 #y_test[i][1,0]
            A=np.array(x_test[i,0]).reshape([1,N])#(scale*x_test[i][0]).reshape([N,1])
            X=np.array(scale*x_test[i][1]).reshape([1,N])
            D=np.array(x_test[i,2]).reshape([1,N])#(scale*x_test[i][2])#.reshape([N,1])
            
            label= np.array(y_test[i]) 
            
            samp=np.append(np.append(A, X, axis=0), D, axis=0)
            D=D.flatten()
            
    
            # @@@ Comments are incorrect        
            # Prediction from MILP
            realY, realS, realIdle=CalcYS(0, label.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
            hSelect.flow_heurDX_CT_best_Ins
            # # Prediction from Select Heuristic
            start_time10 = time.time()
            HeurOrders10, Heur_late_totals10, Heur_fin_totals10 = hSelect.flow_heurDX_CT_best_Ins(A,D,X,p,q,numIns[0])
            end_time10 = time.time()
            execution_time_heur10[i] = end_time10 - start_time10

            # # Prediction from Select Heuristic
            start_time15 = time.time()
            HeurOrders15, Heur_late_totals15, Heur_fin_totals15 = hSelect.flow_heurDX_CT_best_Ins(A,D,X,p,q,numIns[1])
            end_time15 = time.time()
            execution_time_heur15[i] = end_time15 - start_time15

            # Prediction from dispatch Heuristic insert last 20
            start_time20 = time.time()
            HeurOrders20, Heur_late_totals20, Heur_fin_totals20 = hSelect.flow_heurDX_CT_best_Ins(A,D,X,p,q,numIns[2])
            end_time20 = time.time()
            execution_time_heur20[i] = end_time20 - start_time20
             
            # Prediction from dispatch Heuristic insert last 30
            start_time30 = time.time()
            HeurOrders30, Heur_late_totals30, Heur_fin_totals30 = hSelect.flow_heurDX_CT_best_Ins(A,D,X,p,q,numIns[3])
            end_time30 = time.time()
            execution_time_heur30[i] = end_time30 - start_time30
             
            # Prediction from dispatch Heuristic insert last 35
            start_time35 = time.time()
            HeurOrders35, Heur_late_totals35, Heur_fin_totals35 = hSelect.flow_heurDX_CT_best_Ins(A,D,X,p,q,numIns[4])
            end_time35 = time.time()
            execution_time_heur35[i] = end_time35 - start_time35
            
           #  # # Prediction from Insert Heuristic
           #  start_time10 = time.time()
           #  HeurOrders10, Heur_late_totals10, Heur_fin_totals10 = hv4.flow_heurDX_CT_Ins(A,D,X,p,q,numIns[0])
           #  end_time10 = time.time()
           #  execution_time_heur10[i] = end_time10 - start_time10

           #  # Prediction from dispatch Heuristic insert last 20
           #  start_time15 = time.time()
           #  HeurOrders15, Heur_late_totals15, Heur_fin_totals15 = hv4.flow_heurDX_CT_Ins(A,D,X,p,q,numIns[1])
           #  end_time15 = time.time()
           #  execution_time_heur15[i] = end_time15 - start_time15

           #  # Prediction from dispatch Heuristic insert last 20
           #  start_time20 = time.time()
           #  HeurOrders20, Heur_late_totals20, Heur_fin_totals20 = hv4.flow_heurDX_CT_Ins(A,D,X,p,q,numIns[2])
           #  end_time20 = time.time()
           #  execution_time_heur20[i] = end_time20 - start_time20
            
           #  # Prediction from dispatch Heuristic insert last 30
           #  start_time30 = time.time()
           #  HeurOrders30, Heur_late_totals30, Heur_fin_totals30 = hv4.flow_heurDX_CT_Ins(A,D,X,p,q,numIns[3])
           #  end_time30 = time.time()
           #  execution_time_heur30[i] = end_time30 - start_time30
            
           #  # Prediction from dispatch Heuristic insert last 30
           #  start_time35 = time.time()
           #  HeurOrders35, Heur_late_totals35, Heur_fin_totals35 = hv4.flow_heurDX_CT_Ins(A,D,X,p,q,numIns[4])
           #  end_time35 = time.time()
           #  execution_time_heur35[i] = end_time35 - start_time35
            
            
           #  # heurY, heurS, heurIdle=CalcYS(0, HeurOrders.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
           # # heurYBest, heurSBest, heurIdleBest=CalcYS(0, HeurOrdersBest.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
            heurY10, heurS10, heurIdle10=CalcYS(0, HeurOrders10.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
            heurY15, heurS15, heurIdle15=CalcYS(0, HeurOrders15.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
            heurY20, heurS20, heurIdle20=CalcYS(0, HeurOrders20.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
            heurY30, heurS30, heurIdle30=CalcYS(0, HeurOrders30.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
            heurY35, heurS35, heurIdle35=CalcYS(0, HeurOrders35.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
           #  # heurY4, heurS4, heurIdle1=CalcYS(0, HeurOrders4.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
           #  # heurY5, heurS5, heurIdle1=CalcYS(0, HeurOrders5.reshape([N,1]), A.T, X.T, np.zeros([N,1]))


            objr[i]=Obj_pq(D,realY,p,q)
            # objHeur[i]=Obj_pq(D,heurY,p,q)
        #    objHeurBest[i]=Obj_pq(D,heurYBest,p,q)
            objHeur10[i]=Obj_pq(D,heurY10,p,q)
            objHeur15[i]=Obj_pq(D,heurY15,p,q)
            objHeur20[i]=Obj_pq(D,heurY20,p,q)
            objHeur30[i]=Obj_pq(D,heurY30,p,q)
            objHeur35[i]=Obj_pq(D,heurY35,p,q)
            # objHeur4[i]=Obj_pq(D,heurY4,p,q)
            # objHeur5[i]=Obj_pq(D,heurY5,p,q)
            
            if j>1:
                objHeurMin[i] = min(objr[i], objHeur10[i], objHeur15[i], objHeur20[i], objHeur30[i], objHeur35[i], objHeurMin[i])
            else:
                objHeurMin[i] = min(objr[i], objHeur10[i], objHeur15[i], objHeur20[i], objHeur30[i], objHeur35[i])
    total_runtimes[0,j]=execution_time_heur10
    total_runtimes[1,j]=execution_time_heur15
    total_runtimes[2,j]=execution_time_heur20     
    total_runtimes[3,j]=execution_time_heur30  
    total_runtimes[4,j]=execution_time_heur35                
    runtimes_vector[j] = np.array([np.sum(execution_time_heur10) / n_test, np.sum(execution_time_heur15) / n_test,np.sum(execution_time_heur20)/ n_test, np.sum(execution_time_heur30)/ n_test, np.sum(execution_time_heur35)/ n_test])
   
    objHeur10s[j]=objHeur10
    objHeur15s[j]=objHeur15
    objHeur20s[j]=objHeur20
    objHeur30s[j]=objHeur30
    objHeur35s[j]=objHeur35
    print(j)

epsilon = 1e-10
for i in range(len(Ks)):
  accuracys_vectors[i] = [sum(objHeurMin>=objHeur10s[i])/ n_test*100, sum(objHeurMin>=objHeur15s[i])/ n_test*100, sum(objHeurMin>=objHeur20s[i])/ n_test*100, sum(objHeurMin>=objHeur30s[i])/ n_test*100, sum(objHeurMin>=objHeur35s[i])/ n_test*100] 
  max_differerence_vectors[i] = [max(objHeur10s[i]-objHeurMin), max(objHeur15s[i]-objHeurMin), max(objHeur20-objHeurMin), max(objHeur30-objHeurMin), max(objHeur35-objHeurMin)]
  mean_difference_vectors[i] = [ (sum(objHeur10s[i]) / (sum(objHeurMin)+epsilon)) * 100, (sum(objHeur15s[i]) / (sum(objHeurMin)+epsilon)) * 100, (sum(objHeur20s[i]) / (sum(objHeurMin)+epsilon)) * 100, (sum(objHeur30s[i]) / (sum(objHeurMin)+epsilon)) * 100, (sum(objHeur35s[i]) / (sum(objHeurMin)+epsilon)) * 100]
  difference_vectors[i] = [ (objHeur10s[i]-objHeurMin), (objHeur15s[i]-objHeurMin), (objHeur20s[i]-objHeurMin), (objHeur30s[i]-objHeurMin), (objHeur35s[i]-objHeurMin)]

  std_difference_vectors[i] = [  st.stdev(objHeur10s[i]-objHeurMin), st.stdev(objHeur15s[i]-objHeurMin), st.stdev(objHeur20s[i]-objHeurMin), st.stdev(objHeur30s[i]-objHeurMin), st.stdev(objHeur35s[i]-objHeurMin)]

    
runtimes_vector = np.array(runtimes_vector).T 
accuracys_vectors =  np.array(accuracys_vectors).T 
max_differerence_vectors = np.array(max_differerence_vectors).T
difference_vectors = np.array(difference_vectors)
mean_difference_vectors = np.array(mean_difference_vectors).T
std_difference_vectors = np.array(std_difference_vectors).T

# Define colors
colors = ['red', 'orange', 'olive', 'lime', 'blue']#,,'purple']
#methods = ['Insert in the last 10', 'Insert in the last 15', 'Insert in the last 20', 'Insert in the last 30', 'Insert in the last 35']#'Selection Heuristic',  , 'Insert the last 10', 'Insert the last 40', 'Insert the last 50']
methods = ['Select from 3', 'Select from 5', 'Select from 10', 'Select from 15', 'Select from 20']
# Plotting

def custom_percentile(data, percentile, axis=1):
    if not (0 <= percentile <= 100):
        raise ValueError("Percentile must be between 0 and 100")
    
    if axis is None:
        data = np.sort(data)
        index = int(np.ceil((percentile / 100) * len(data))) - 1
        return data[index]
    else:
        sorted_data = np.sort(data, axis=axis)
        if percentile<50:
            indices = np.ceil((percentile / 100.0) * np.take(sorted_data.shape, axis)).astype(int) - 1
        else:
            indices = np.ceil((percentile / 100.0) * np.take(sorted_data.shape, axis)).astype(int)
        # Adjust indices to ensure they stay within the bounds of the array
        indices = np.clip(indices, 0, sorted_data.shape[axis] - 1)
        percs=sorted_data[:,indices]
        return percs


def calculate_stats(data):
    means = np.mean(data, axis=1)
    percentiles_5 = custom_percentile(data, 5, axis=1)
    percentiles_95 = custom_percentile(data, 95, axis=1)
    error_bars = np.array([means - percentiles_5, percentiles_95 - means])
    return means, error_bars

# Plot with error bars: Runtime vs Kept Perms
plt.figure(figsize=(12, 8))

# Calculate statistics for each algorithm
alg_means = np.zeros([len(total_runtimes), len(Ks)])
error_bars = np.zeros([len(total_runtimes), 2, len(Ks)])
for i in range(len(total_runtimes)):
    alg_means[i], error_bars[i] = calculate_stats(total_runtimes[i])
    # Plotting for each algorithm
    plt.errorbar(Ks, alg_means[i], yerr=error_bars[i], color=colors[i], fmt='-s', capsize=5, label=methods[i])

# Customizing the plot
plt.xlabel('Kept Permutations')
plt.ylabel('Time (Seconds)')
plt.title('Average Runtimes vs Number of Kept Permutations for '+str(nb_instances[0])+' instances of '+str(Ns[0])+' jobs with Error Bars (5th to 95th Percentile)')
plt.legend()
#plt.yscale('log')
plt.show()


# Plot with error bars: Obj Difference vs Kept Perms
plt.figure(figsize=(12, 8))

alg_means = np.zeros([len(total_runtimes), len(Ks)])
error_bars = np.zeros([len(total_runtimes), 2, len(Ks)])
for i in range(len(total_runtimes)):
    alg_means[i], error_bars[i] = calculate_stats(difference_vectors[:,i])

    #plt.plot(Ks, alg_means[i], color=colors[i], label=methods[i])
    # Plotting for each algorithm
    plt.errorbar(Ks+(i*0.6), alg_means[i], yerr=error_bars[i], color=colors[i], fmt='-s', capsize=5, label=methods[i])

# Customizing the plot
plt.xlabel('Kept Permutations')
plt.ylabel('Objective Difference from Best')
plt.title('Average Difference vs Number of Kept Permutations for '+str(nb_instances[0])+' instances of '+str(Ns[0])+' jobs with Error Bars (5th to 95th Percentile)')
plt.legend()
#plt.yscale('log')
plt.show()


# Scatter Plot: Obj Difference vs Kept Permutations
plt.figure(figsize=(12, 8))

for i in range(len(total_runtimes)):
    # Plotting for each algorithm
    plt.scatter((np.ones([100,1])*np.array(Ks).reshape([1,-1])).T.flatten()+(i*0.6), difference_vectors[:,i].flatten(), color=colors[i], label=methods[i])

# Customizing the plot
plt.xlabel('Kept Permutations')
plt.ylabel('Objective Difference from Best')
plt.title('Difference vs Number of Kept Permutations for '+str(nb_instances[0])+' instances of '+str(Ns[0])+' jobs')
plt.legend(bbox_to_anchor=(0.5, 1.1), loc='upper center', ncol=5)
#plt.yscale('log')
plt.show()

# Plot each Kept to compare Obj vs Instance
# for run in range(5):
#     plt.figure(figsize=(20, 8))
#     for alg in range(len(numIns)):
#         instance_numbers = np.arange(nb_instances[0])
#         # Assuming `objective_values[alg]` has multiple runs, we will index it with `run`
#         plt.scatter(4*instance_numbers+alg*0.6, difference_vectors[run,alg], label=methods[alg])
#     plt.title("Performance by Instance for "+str(Ks[run])+" Kept Permutations")
#     plt.xlabel('Instance Number')
#     plt.ylabel('Objective Value')
#     plt.legend()
#     plt.show()

# # Calculate standard deviations

# std_devs = (((accuracys_vectors/100) * (1 - (accuracys_vectors/100))) / nb_instances[0]) *100

# # Plotting
# fig, ax = plt.subplots(figsize=(10, 6))

# for i in range(accuracys_vectors.shape[0]):
#     # # Convert number of jobs to integers for proper spacing
#     # x = np.arange(1, len(names) + 1)

#     # Plot each line with error bars
#     ax.errorbar(10, accuracys_vectors[i], yerr=2*std_devs[i], fmt='o', color=colors[i], label=methods[i])

#     ax.plot(10, accuracys_vectors[i], marker='o', color=colors[i])

# ax.set_title('Objective Accuracy (%) for The best of dispatch rules using Pareto as exact algorithm   for ' + str(nb_instances[0]) + ' instances')
# ax.set_xlabel('Number of Jobs')
# ax.set_ylabel('Accuracy')
# #ax.set_xticks(x)
# #ax.set_xticklabels(names)
# ax.legend()
# # Set y-axis scale to logarithmic
# #ax.set_yscale('log')
# plt.tight_layout()
# plt.show()




# fig, ax = plt.subplots(figsize=(10, 6))

# for i in range(std_difference_vectors.shape[0] ):
#     # # Convert number of jobs to integers for proper spacing
#     # x = np.arange(1, len(names) + 1)

#     # Plot each line
#     ax.plot(10, std_difference_vectors[i], marker='o', color=colors[i], label=methods[i])

# ax.set_title('Standard deviation of Objective Difference for ' + str(nb_instances[0]) + ' instances')
# ax.set_xlabel('Number of Jobs')
# ax.set_ylabel('Standard deviation')
# #ax.set_xticks(x)
# #ax.set_xticklabels(names)
# ax.legend()
# # Set y-axis scale to logarithmic

# plt.tight_layout()
# plt.show()


# fig, ax = plt.subplots(figsize=(10, 6))

# for i in range(mean_difference_vectors.shape[0]  ):
#     # # Convert number of jobs to integers for proper spacing
#     # x = np.arange(1, len(names) + 1)

#     # Plot each line
#     ax.plot(10, mean_difference_vectors[i], marker='o', color=colors[i], label=methods[i])

# ax.set_title('Average Objective Difference (%) for ' + str(nb_instances[0]) + ' instances')
# ax.set_xlabel('Number of Jobs')
# ax.set_ylabel('Average Objective Difference (%)')
# #ax.set_xticks(x)
# #ax.set_xticklabels(names)
# ax.legend()
# #ax.set_yscale('log')
# plt.tight_layout()
# plt.show()




# # percentiles = [90, 95, 99]
# # linestyles = ['-', '--', ':']
# # fig, ax = plt.subplots(figsize=(10, 6))
# # for method_idx in range(len(methods) ):
# #     data_method = difference_vectors[:,method_idx,:]
# #     data_method = np.sort(data_method, axis=1)
    

# #     nom_methode = methods[method_idx]
# #     couleur = colors[method_idx]

# #     for percentile, style_ligne in zip(percentiles, linestyles):
# #         valeur_percentile = np.percentile(data_method, percentile, axis=1)


# #         ax.plot(range(1, len(names) + 1), valeur_percentile, marker='o', linestyle=style_ligne, color=couleur,
# #                 label=f"{nom_methode} - {percentile}th percentile")

# # ax.set_title('Percentiles Objective Difference for ' + str(nb_instances[0]) + ' instances')
# # ax.set_xlabel('Number of Jobs')
# # ax.set_ylabel('Difference')
# # ax.set_xticks(np.arange(1, len(names) + 1))
# # ax.set_xticklabels(names)
# # ax.legend()

# # plt.tight_layout()
# # plt.show()



# data_runtime = pd.DataFrame(data = runtimes_vectors, columns = names, index = methods )
# data_runtime.index.name = "runtimes"

# data_accuracy = pd.DataFrame(data = accuracys_vectors, columns = names, index = methods )
# data_accuracy.index.name = "accuracy"

# data_std = pd.DataFrame(data = std_difference_vectors, columns = names, index = methods)
# data_std.index.name = "std"

# data_mean = pd.DataFrame(data = mean_difference_vectors, columns = names, index = methods)
# data_mean.index.name = "mean"

# with open('Output/runtimesBest.pkl', 'wb') as file:
#   pickle.dump(data_runtime, file)

# with open('Output/accuracyBest.pkl', 'wb') as file:
#   pickle.dump(data_accuracy, file)

# with open('Output/stdBest.pkl', 'wb') as file:
#   pickle.dump(data_std, file)
  
# with open('Output/meanBest.pkl', 'wb') as file:
#   pickle.dump(data_mean, file)
  

# print('\nExecution Time per instances')
# display(data_runtime)

with open('Output/timeVsNKEEP_50N_Selection.pkl','wb') as file:
    pickle.dump(runtimes_vector, file)
    pickle.dump(accuracys_vectors, file)
    pickle.dump(max_differerence_vectors, file)
    pickle.dump(mean_difference_vectors, file)
    pickle.dump(difference_vectors, file)
    pickle.dump(std_difference_vectors, file)
    #pickle.dump(execution_time_heurBest, file)
    pickle.dump(execution_time_heur10, file)
    pickle.dump(execution_time_heur20, file)
    pickle.dump(execution_time_heur30, file)
    pickle.dump(execution_time_heur35, file)
    pickle.dump(total_runtimes, file)
    pickle.dump(objHeur10s, file)
    pickle.dump(objHeur15s, file)
    pickle.dump(objHeur20s, file)
    pickle.dump(objHeur30s, file)
    pickle.dump(objHeur35s, file)
    pickle.dump(objHeurMin, file)