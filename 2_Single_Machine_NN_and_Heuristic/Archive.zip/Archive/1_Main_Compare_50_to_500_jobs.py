# -*- coding: utf-8 -*-


import pickle
import numpy as np
import statistics as st
from matplotlib import pyplot as plt
from Functions.FlowshopBaseSchedRoutines import Obj_pq
from Functions.Heuristic_v4_CT import *
from Functions.Heuristics.Pareto_Heuristics import flow_heurDX_CT_best
import time
from math import *
import pandas as pd

# Paths to training/validation data and testing data respectively
dataFilePaths = ["Data/single_machine_50N.pickle", "Data/single_machine_100N.pickle","Data/single_machine_150N.pickle", "Data/single_machine_200N.pickle","Data/single_machine_250N.pickle","Data/single_machine_300N.pickle","Data/single_machine_350N.pickle","Data/single_machine_400N.pickle"]#,"Data/single_machine_450N.pickle","Data/single_machine_500N.pickle"] 
#dataFilePath = 'C:/Users/USER/My Drive/teaching/Spring2023/Matt/Codes/1_MILP_exact_single_and_multi_machine_algorithms/single_machine_examples.pickl
saveFile = ['singleMachineModel_50N.pickle','singleMachineModel_100N.pickle']
saveModel = False
# Number of jobs
Ns=[50,100,150,200,250,300,350,400]#,450,500]  
# Lateness for objective function: penalty & rate
p=50
q=1
nb_instances = [10,10,10,10,10,10,10,10]#,10,10,10,10]#
runtimes_vectors = []
accuracys_vectors = []
mean_difference_vectors = []
difference_vectors = []
max_differerence_vectors  = []
std_difference_vectors  = []
### Compute the start and finish times based on system parameters and the given job order (copied from MILP code, and simplified to only do 1 machine)
def CalcYS(m0,job,Am0,X,Z):
    N,M=X.shape
    #Starting time(S) and finishing time(Y)
    S=np.empty((N,M))
    Y=np.empty((N,M))
    Idle =np.empty((N,M))

    j=int(job[0,m0])
    # First Stage:
    S[j,m0]=Am0[j]+Z[j,m0]
    Y[j,m0]=S[j,m0]+X[j,m0]
    Idle[j,m0] = 0

    for jn in range(1,N):
        j=int(job[jn,m0])
        S[j,m0]=max(Am0[j]+Z[j,m0],Y[int(job[jn-1,m0]),m0])
        Y[j,m0]=S[j,m0]+X[j,m0]
        Idle[j,m0] = S[j,m0]-Y[int(job[jn-1,m0]),m0]
        
    return Y,S,Idle





#print("Total instances :",nb_instances )
for file in  range(len(dataFilePaths)):
    all_arrival=[]
    all_work=[]
    all_due=[]
    all_labels=[]
    # Save scale factors(to compute objective function)
    all_scale = []
    dataFilePath = dataFilePaths[file]
    N = Ns[file]
    with open(dataFilePath, 'rb') as f:
        while True:
            try:
                data = pickle.load(f)
                #scale per instance so max due  time =1
                scale = 1#np.max(data['D'])
                all_scale.append(scale)
                all_arrival.append(data['A']/scale) 
                all_work.append(data['X']/scale)
                all_due.append(data['D']/scale)
                label=np.zeros([1,N])
                label[0]=data['order']
               # label[1]=scale
                all_labels.append(label)
            except EOFError:
                # Reached the end of the file
                break
    all_scale = np.array(all_scale)
    all_labels=np.squeeze(all_labels, axis=1)
    
    instance=np.zeros([3,N])
    inputs=np.zeros([len(all_arrival),3,N])
    for i in range(len(all_arrival)):
        instance[0]=all_arrival[i]
        instance[1]=all_work[i].flatten()
        instance[2]=all_due[i]
        
        inputs[i]=instance ########################################
    x_test,y_test = inputs, all_labels
    
    # Count of accurate objective predictions and arrays for objective values of NN, MILP, and random for comparison
    count=0
    n_test = nb_instances[file]
    objr=np.zeros(n_test) #MILP

    #objHeur=np.zeros(n_test) #Heuristic
    # Sewa Heuristic
    objHeurBest=np.zeros(n_test) 
    # Heuristic keep 10, 20, 30, 40, 50
    #objHeur1, , objHeur4, objHeur5 = , np.zeros(n_test), np.zeros(n_test), np.zeros(n_test) 
    objHeur2, objHeur3 = np.zeros(n_test), np.zeros(n_test)
    # Best obj value
    objHeurMin = np.zeros(n_test)

    runtimes_vector = []
    accuracys_vector = []

    execution_time_heur, execution_time_heurBest, execution_time_heur20, execution_time_heur30 = 0,0,0,0
    #execution_time_heur10, execution_time_heur40, execution_time_heur50 = 0,0,0


    for i in range(n_test):
            scale=1 #y_test[i][1,0]
            A=np.array(x_test[i,0]).reshape([1,N])#(scale*x_test[i][0]).reshape([N,1])
            X=np.array(scale*x_test[i][1]).reshape([1,N])
            D=np.array(x_test[i,2]).reshape([1,N])#(scale*x_test[i][2])#.reshape([N,1])
            
            label= np.array(y_test[i]) 
            
            samp=np.append(np.append(A, X, axis=0), D, axis=0)
            D=D.flatten()
            
    
            # Prediction from MILP
            realY, realS, realIdle=CalcYS(0, label.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
            

            # # Prediction from dispatch Heuristic 
            # start_time = time.time()             
            # HeurOrders, lat, fin = flow_heurDX_CT(A,D,X,p,q)
            # end_time = time.time()
            # execution_time_heur += end_time - start_time
            
            # Prediction from pareto Heuristic 
            start_time = time.time()             
            HeurOrdersBest, Heur_late_totalsBest, Heur_fin_totalsBest = flow_heurDX_CT_best(A,D,X,p,q)
            end_time = time.time()
            execution_time_heurBest += end_time - start_time
            
            # # Prediction from dispatch Heuristic insert last 10
            # start_time1 = time.time()
            # HeurOrders1, Heur_late_totals1, Heur_fin_totals1 = flow_heurDX_CT_Ins(A,D,X,p,q,10)
            # end_time1 = time.time()
            # execution_time_heur10 += end_time1 - start_time1
            
            # Prediction from dispatch Heuristic insert last 20
            start_time2 = time.time()
            HeurOrders2, Heur_late_totals2, Heur_fin_totals2 = flow_heurDX_CT_Ins(A,D,X,p,q,20)
            end_time2 = time.time()
            execution_time_heur20 += end_time2 - start_time2
            
            # Prediction from dispatch Heuristic insert last 30
            start_time3 = time.time()
            HeurOrders3, Heur_late_totals3, Heur_fin_totals3 = flow_heurDX_CT_Ins(A,D,X,p,q,30)
            end_time3 = time.time()
            execution_time_heur30 += end_time3 - start_time3
            
            # # Prediction from dispatch Heuristic insert last 40
            # start_time4 = time.time()
            # HeurOrders4, Heur_late_totals4, Heur_fin_totals4 = flow_heurDX_CT_Ins(A,D,X,p,q,40)
            # end_time4 = time.time()
            # execution_time_heur40 += end_time4 - start_time4
            
            # # Prediction from dispatch Heuristic insert last 50
            # start_time5 = time.time()
            # HeurOrders5, Heur_late_totals5, Heur_fin_totals5 = flow_heurDX_CT_Ins(A,D,X,p,q,50)
            # end_time5 = time.time()
            # execution_time_heur50 += end_time5 - start_time5
            
            
            # heurY, heurS, heurIdle=CalcYS(0, HeurOrders.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
            heurYBest, heurSBest, heurIdleBest=CalcYS(0, HeurOrdersBest.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
            # heurY1, heurS1, heurIdle1=CalcYS(0, HeurOrders1.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
            heurY2, heurS2, heurIdle1=CalcYS(0, HeurOrders2.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
            heurY3, heurS3, heurIdle1=CalcYS(0, HeurOrders3.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
            # heurY4, heurS4, heurIdle1=CalcYS(0, HeurOrders4.reshape([N,1]), A.T, X.T, np.zeros([N,1]))
            # heurY5, heurS5, heurIdle1=CalcYS(0, HeurOrders5.reshape([N,1]), A.T, X.T, np.zeros([N,1]))


            objr[i]=Obj_pq(D,realY,p,q)
            # objHeur[i]=Obj_pq(D,heurY,p,q)
            objHeurBest[i]=Obj_pq(D,heurYBest,p,q)
            # objHeur1[i]=Obj_pq(D,heurY1,p,q)
            objHeur2[i]=Obj_pq(D,heurY2,p,q)
            objHeur3[i]=Obj_pq(D,heurY3,p,q)
            # objHeur4[i]=Obj_pq(D,heurY4,p,q)
            # objHeur5[i]=Obj_pq(D,heurY5,p,q)
            
            objHeurMin[i] = min(objr[i], objHeurBest[i], objHeur2[i], objHeur3[i])
                            
    runtimes_vector = [execution_time_heurBest / n_test, execution_time_heur20/ n_test, execution_time_heur30/ n_test]#,
                        #execution_time_heur10/ n_test, execution_time_heur40/ n_test, execution_time_heur50/ n_test] 
   
    accuracys_vector = [ sum(objHeurMin>=objHeurBest)/ n_test*100, sum(objHeurMin>=objHeur2)/ n_test*100, sum(objHeurMin>=objHeur3)/ n_test*100]
                        #sum(objHeurMin>=objHeur1)/ n_test*100, sum(objHeurMin>=objHeur4)/ n_test*100, sum(objHeurMin>=objHeur5)/ n_test*100 ] 
    max_differerence_vector = [max(objHeurBest-objHeurMin),  max(objHeur2-objHeurMin), max(objHeur3-objHeurMin)]# max(objHeur1-objHeurMin), max(objHeur4-objHeurMin), max(objHeur5-objHeurMin)]
    mean_difference_vector = [(sum(objHeurBest) / sum(objHeurMin)) * 100,  (sum(objHeur2) / sum(objHeurMin)) * 100, (sum(objHeur3) / sum(objHeurMin)) * 100]
                              #(sum(objHeur1) / sum(objHeurMin)) * 100,  (sum(objHeur4) / sum(objHeurMin)) * 100, (sum(objHeur5) / sum(objHeurMin)) * 100]
    difference_vector = [(objHeurBest-objHeurMin),  (objHeur2-objHeurMin), (objHeur3-objHeurMin)]#, (objHeur1-objHeurMin), (objHeur4-objHeurMin), (objHeur5-objHeurMin)]

    std_difference_vector = [ st.stdev(objHeurBest-objHeurMin),   st.stdev(objHeur2-objHeurMin), st.stdev(objHeur3-objHeurMin)]
                             #.stdev(objHeur1-objHeurMin), st.stdev(objHeur4-objHeurMin), st.stdev(objHeur5-objHeurMin)]
    
    runtimes_vectors.append(runtimes_vector)
    accuracys_vectors.append(accuracys_vector)
    max_differerence_vectors.append(max_differerence_vector)
    mean_difference_vectors.append(mean_difference_vector)
    difference_vectors.append(difference_vector)
    std_difference_vectors.append(std_difference_vector)
    print(file)

    
runtimes_vectors = np.array(runtimes_vectors).T 
accuracys_vectors =  np.array(accuracys_vectors).T 
max_differerence_vectors = np.array(max_differerence_vectors).T
difference_vectors = np.array(difference_vectors)
mean_difference_vectors = np.array(mean_difference_vectors).T
std_difference_vectors = np.array(std_difference_vectors).T


# Define colors
colors = ['red','orange','olive', 'green', 'blue','purple']
methods = ['Pareto Heuristic',  'Insert the last 20', 'Insert the last 30']#, 'Insert the last 10', 'Insert the last 40', 'Insert the last 50']
names = ["50 jobs", "100 jobs", "150 jobs", "200 jobs", "250 jobs", "300 jobs","350 jobs", "400 jobs"]#,"450 jobs", "500 jobs"] 
# Plotting

fig, ax = plt.subplots(figsize=(10, 6))

for i in range(runtimes_vectors.shape[0]):
    # Convert number of jobs to integers for proper spacing
    x = np.arange(1, len(names) + 1)

    # Plot each line
    ax.plot(x, runtimes_vectors[i], marker='o', color=colors[i], label=methods[i])

ax.set_title('Execution Time per instances')
ax.set_xlabel('Number of Jobs')
ax.set_ylabel('Time (seconds)')
ax.set_xticks(x)
ax.set_xticklabels(names)
ax.legend()

# Set y-axis scale to logarithmic
ax.set_yscale('log')

plt.tight_layout()
plt.show()


# Calculate standard deviations

std_devs = (((accuracys_vectors/100) * (1 - (accuracys_vectors/100))) / nb_instances[0]) *100

# Plotting
fig, ax = plt.subplots(figsize=(10, 6))

for i in range(accuracys_vectors.shape[0]):
    # Convert number of jobs to integers for proper spacing
    x = np.arange(1, len(names) + 1)

    # Plot each line with error bars
    ax.errorbar(x, accuracys_vectors[i], yerr=2*std_devs[i], fmt='o', color=colors[i], label=methods[i])

    ax.plot(x, accuracys_vectors[i], marker='o', color=colors[i])

ax.set_title('Objective Accuracy (%) for The best of dispatch rules using Pareto as exact algorithm   for ' + str(nb_instances[0]) + ' instances')
ax.set_xlabel('Number of Jobs')
ax.set_ylabel('Accuracy')
ax.set_xticks(x)
ax.set_xticklabels(names)
ax.legend()
# Set y-axis scale to logarithmic
#ax.set_yscale('log')
plt.tight_layout()
plt.show()




fig, ax = plt.subplots(figsize=(10, 6))

for i in range(std_difference_vectors.shape[0] ):
    # Convert number of jobs to integers for proper spacing
    x = np.arange(1, len(names) + 1)

    # Plot each line
    ax.plot(x, std_difference_vectors[i], marker='o', color=colors[i], label=methods[i])

ax.set_title('Standard deviation of Objective Difference for ' + str(nb_instances[0]) + ' instances')
ax.set_xlabel('Number of Jobs')
ax.set_ylabel('Standard deviation')
ax.set_xticks(x)
ax.set_xticklabels(names)
ax.legend()
# Set y-axis scale to logarithmic

plt.tight_layout()
plt.show()


fig, ax = plt.subplots(figsize=(10, 6))

for i in range(mean_difference_vectors.shape[0]  ):
    # Convert number of jobs to integers for proper spacing
    x = np.arange(1, len(names) + 1)

    # Plot each line
    ax.plot(x, mean_difference_vectors[i], marker='o', color=colors[i], label=methods[i])

ax.set_title('Average Objective Difference (%) for ' + str(nb_instances[0]) + ' instances')
ax.set_xlabel('Number of Jobs')
ax.set_ylabel('Average Objective Difference (%)')
ax.set_xticks(x)
ax.set_xticklabels(names)
ax.legend()
#ax.set_yscale('log')
plt.tight_layout()
plt.show()




# percentiles = [90, 95, 99]
# linestyles = ['-', '--', ':']
# fig, ax = plt.subplots(figsize=(10, 6))
# for method_idx in range(len(methods) ):
#     data_method = difference_vectors[:,method_idx,:]
#     data_method = np.sort(data_method, axis=1)
    

#     nom_methode = methods[method_idx]
#     couleur = colors[method_idx]

#     for percentile, style_ligne in zip(percentiles, linestyles):
#         valeur_percentile = np.percentile(data_method, percentile, axis=1)


#         ax.plot(range(1, len(names) + 1), valeur_percentile, marker='o', linestyle=style_ligne, color=couleur,
#                 label=f"{nom_methode} - {percentile}th percentile")

# ax.set_title('Percentiles Objective Difference for ' + str(nb_instances[0]) + ' instances')
# ax.set_xlabel('Number of Jobs')
# ax.set_ylabel('Difference')
# ax.set_xticks(np.arange(1, len(names) + 1))
# ax.set_xticklabels(names)
# ax.legend()

# plt.tight_layout()
# plt.show()



data_runtime = pd.DataFrame(data = runtimes_vectors, columns = names, index = methods )
data_runtime.index.name = "runtimes"

data_accuracy = pd.DataFrame(data = accuracys_vectors, columns = names, index = methods )
data_accuracy.index.name = "accuracy"

data_std = pd.DataFrame(data = std_difference_vectors, columns = names, index = methods)
data_std.index.name = "std"

data_mean = pd.DataFrame(data = mean_difference_vectors, columns = names, index = methods)
data_mean.index.name = "mean"

with open('Output/runtimesBest.pkl', 'wb') as file:
  pickle.dump(data_runtime, file)

with open('Output/accuracyBest.pkl', 'wb') as file:
  pickle.dump(data_accuracy, file)

with open('Output/stdBest.pkl', 'wb') as file:
  pickle.dump(data_std, file)
  
with open('Output/meanBest.pkl', 'wb') as file:
  pickle.dump(data_mean, file)
  

print('\nExecution Time per instances')
display(data_runtime)

