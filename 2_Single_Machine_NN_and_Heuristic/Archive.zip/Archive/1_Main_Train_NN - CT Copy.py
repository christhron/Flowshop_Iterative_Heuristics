# This code turns permutations into a scalar label. Probably is not useful.

# -*- coding: utf-8 -*-
"""
Created on Mon Jul  3 08:51:09 2023

@author: matth
"""

import pickle
import numpy as np
import tensorflow as tf
from tensorflow.keras.layers import Dense, Flatten, Input
from sklearn.model_selection import train_test_split
import statistics as st
from matplotlib import pyplot as plt
from FlowshopBaseSchedRoutines import Obj_pq

#plt.style.use('seaborn-deep')


# Paths to training/validation data and testing data respectively
dataFilePath = "single_machine_6M.pickle"
#dataFilePath = 'C:/Users/USER/My Drive/teaching/Spring2023/Matt/Codes/1_MILP_exact_single_and_multi_machine_algorithms/single_machine_examples.pickle'

modelname= 'Default Model Structure' #Double Sigmoid


        
### Compute the start and finish times based on system parameters and the given job order (copied from MILP code, and simplified to only do 1 machine)
def CalcYS(m0,job,Am0,X,Z):
    N,M=X.shape
    #Starting time(S) and finishing time(Y)
    S=np.empty((N,M))
    Y=np.empty((N,M))
    Idle =np.empty((N,M))

    j=int(job[0,m0])
    # First Stage:
    S[j,m0]=Am0[j]+Z[j,m0]
    Y[j,m0]=S[j,m0]+X[j,m0]
    Idle[j,m0] = 0

    for jn in range(1,N):
        j=int(job[jn,m0])
        S[j,m0]=max(Am0[j]+Z[j,m0],Y[int(job[jn-1,m0]),m0])
        Y[j,m0]=S[j,m0]+X[j,m0]
        Idle[j,m0] = S[j,m0]-Y[int(job[jn-1,m0]),m0]
        
    return Y,S,Idle
nI = 3
inputs=[]
labels=[]
# Save scale factors(to compute objective function)
all_scale = []
with open(dataFilePath, 'rb') as f:
    while True:
        try:
            data = pickle.load(f)
            #scale per instance so max due  time =1
            scale = np.max(data['D'])
            # label[1]=scale
            labels.append(data['order'].astype(int))
            thisInput = np.array([data['A'],
                           data['X'].flatten(),
                           data['D'],
                           data['A']+data['X'].flatten(),
                           data['D']-(data['A']+data['X'].flatten()),
                           data['A']*0+data['q']/data['p']])
            inputs.append(thisInput/max(data['D']))
        except EOFError:
            # Reached the end of the file
            break
        
N = len(data['A'])        
mVec =  N**np.arange(nI)

labels0 = np.array(labels)[:,:nI]@mVec

import itertools

# Create a list of numbers from 1 to N
numbers = np.arange(N)

# Generate all permutations of the list of numbers
combins = list(itertools.combinations(numbers,nI))

labels1 = []
for cc in combins:
    labels1 = labels1 + list(itertools.permutations(cc))
    
labels1 = np.array(labels1)@mVec

labels = 0*labels0
for j in range(len(labels1)):
    labels[labels0==labels1[j]] = j




    
x_train, x_test, y_train, y_test = train_test_split(inputs, labels, test_size=2000)
x_train, x_val, y_train, y_val = train_test_split(x_train, y_train, test_size=0.2)

